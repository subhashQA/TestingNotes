package javaexample;

class FinalMethod
{
	void m1()
	{
		System.out.println("Inside m1 of super class");
	}
}
public class FinalMethodExample extends FinalMethod{

	void m1()
	{
		System.out.println("Inside m1 of sub class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
