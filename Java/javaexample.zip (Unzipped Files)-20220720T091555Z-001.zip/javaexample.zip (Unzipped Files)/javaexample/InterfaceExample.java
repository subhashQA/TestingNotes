package javaexample;
interface WebDriver
{
	float pi=3.14f;
	void get();
	void method2();
}
public class ChromeDriver implements WebDriver{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChromeDriver obj=new ChromeDriver();
		obj.get();
	}
	public void get()
	{
		System.out.println("Definication of method 1");
		System.out.println("Value of PI is " +pi);
		
	}
	public void method2() {
		// TODO Auto-generated method stub
		
	}	
}
