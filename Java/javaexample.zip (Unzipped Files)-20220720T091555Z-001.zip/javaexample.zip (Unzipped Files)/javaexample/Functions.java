package javaexample;

public class Functions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Functions obj=new Functions();
		int sum=obj.add(10,20);// function calling
		System.out.println("Addition of two numbers are " +sum);
		System.out.println("After function calling");
		sum=obj.add(30,40);
		System.out.println("Addition of two numbers are " +sum);
	}
/* function
	definition
	*/
int add(int x, int y)
{
	int sum=x+y;
	return(sum);
	
}

}
