package javaexample;

public class CompareStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    // create 3 strings
	    String first = "java programming";
	    String second = "java programming";
	    String third = "python programming";

	    // compare first and second strings
	    boolean result1 = first.equals(second);
	    System.out.println("Strings first and second are equal: " + result1);

	    // compare first and third strings
	    boolean result2 = first.equals(third);
	    System.out.println("Strings first and third are equal: " + result2);

	}

}
