package javaexample;

public class ToStringOverride {

	int rollno;  
	String name;  
	String city;  
	  
	ToStringOverride(int rollno, String name, String city){  
	 this.rollno=rollno;  
	 this.name=name;  
	 this.city=city;  
	 }
	public String toString(){//overriding the toString() method  
		  return rollno+" "+name+" "+city;  
		 }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ToStringOverride s1=new ToStringOverride(1,"Ashok","Hyderabad");  
		ToStringOverride s2=new ToStringOverride(2,"Anil","Missisaga");  
		System.out.println(s1);//compiler writes here s1.toString();
		System.out.println(s2);//compiler writes here s2.toString();  
		 } 

}
//Java compiler internally calls toString() method, overriding this method will return the specified values of 
//s1 and s2 objects of the class.