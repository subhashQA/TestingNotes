package javaexample;
class GrandFather
{
	public void login()
	{
		System.out.println("login code");
	}
}

class Father extends GrandFather
{
	public void addBeneficiary()
	{
		System.out.println("addBeneficiary code");
	}
	

}

public class MultiLevelInheritence extends Father{

	void transferFunds()
	{
		System.out.println("transfferFunds code");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultiLevelInheritence obj=new MultiLevelInheritence();
		obj.login();
		obj.addBeneficiary();
		obj.transferFunds();

	}

}
