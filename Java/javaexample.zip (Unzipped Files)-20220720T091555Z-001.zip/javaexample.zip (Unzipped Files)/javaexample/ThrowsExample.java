package javaexample;

class Class1
{
	void method1() throws ArithmeticException
	{
		System.out.println("method one code which may throw run time exception");
	}
}
public class ThrowsExample extends Class1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class1 obj=new Class1();
		try
		{
			obj.method1();
		}
		catch(ArithmeticException e)
		{
			System.out.println("catch code");
		}
		System.out.println("Rest of the code");
	}

}
