package javaexample;

public class ReverseStringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "ABCD";
		String reverseString="";
        char ch;
       
      System.out.print("Original word: ");
      System.out.println(str); //Example word
       
      for (int i=0; i<str.length(); i++)
      {
        ch= str..charAt(i); //extracts each character
        reverseString= ch+reverseString; //adds each character in front of the existing string
      }
      System.out.println("Reversed word: "+ reverseString);
		    
	}

}
