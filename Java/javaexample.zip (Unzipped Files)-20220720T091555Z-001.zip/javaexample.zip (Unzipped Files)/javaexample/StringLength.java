package javaexample;

public class StringLength {

	public static void main(String[] args) {

	    // create a string
	    String str1 = "Ashok Reddy";
	    System.out.println("String: " + str1);

	    // get the length of greet
	    int length = str1.length();
	    System.out.println("String Length is: " + length);
	  }
}
