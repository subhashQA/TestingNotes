package javaexample;

public class TryCatchExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{  
			int data=50/0;  
			System.out.println("After Exception in try block");
	    }
	  catch(ArithmeticException  e)
	  {
		  System.out.println("Please do not enter zero for value B");
		  data=50/1;
		 // System.out.println("Exeception Couught " +e);
		
	  } 
	 
	System.out.println("rest of the code...");
	}  
	}