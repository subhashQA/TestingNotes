package javaexample;
public class StaticKeyWord {

	String name;
	int rolno;
	String group;
	static String collegeName;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			StaticKeyWord st1=new StaticKeyWord();
			st1.init("Ashok", 1, "Mpc");
			StaticKeyWord st2=new StaticKeyWord();
			StaticKeyWord st3=new StaticKeyWord();
			st2.init("Ankush", 2, "Mpc");
			st3.init("DhanShree", 2, "Bpc");
			StaticKeyWord.collegeName();
			st1.display();
			st2.display();
			st3.display();
		}
	public static void collegeName()
	{
		collegeName="Abc";
		
		
	}
	public void init(String name,int rolno,String group)
	{
		this.name=name;
		this.rolno=rolno;
		this.group=group;
	}
	public void display()
	{
		System.out.println("Student name is " +name);
		System.out.println("Student Id is " +rolno);
		System.out.println("Student group is " +group);
		System.out.println("CollegeName is " +collegeName);

	}
	
}