package javaexample;

public class StaticBlock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main Method executed");
	}
	static {
		System.out.println("Static blcok executed");
	}

}
