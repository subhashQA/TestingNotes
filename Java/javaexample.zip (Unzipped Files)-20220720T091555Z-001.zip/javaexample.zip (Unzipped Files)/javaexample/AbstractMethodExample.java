package javaexample;
abstract class Abc
{
//	static final float pi=3.14f;
	abstract void method1();
	public void method2()
	{
		System.out.println("Method 2 code");
	}
	
}
public class AbstractMethodExample extends Abc{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AbstractMethodExample obj=new AbstractMethodExample();
		obj.method1();
		obj.method2();
	}

}
