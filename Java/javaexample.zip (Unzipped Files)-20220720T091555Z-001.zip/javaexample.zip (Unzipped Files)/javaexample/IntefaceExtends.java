package javaexample;
interface interface4
{
	void method1();
	
}
interface interface5 extends interface4
{
	void method2();
	
}
public class IntefaceExtends implements interface5{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntefaceExtends obj=new IntefaceExtends();
		obj.method1();
		obj.method2();
	}
	
	public void method1()
	{
		System.out.println("Dfination of method1");
	}
	public void method2()
	{
		System.out.println("Dfination of method 2");
	}
}
