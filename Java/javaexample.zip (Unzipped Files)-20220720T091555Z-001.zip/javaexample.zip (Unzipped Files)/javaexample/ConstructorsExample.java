package javaexample;

public class ConstructorsExample {

	String name;
	int rolno;
	String group;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConstructorsExample st1=new ConstructorsExample("Ashok", 1, "Mpc");
		ConstructorsExample st2=new ConstructorsExample("Ankush", 2, "Bpc");
		ConstructorsExample st3=new ConstructorsExample("Dhanshree", 3, "Mpc");
		st1.display();
		st2.display();
		st3.display();
		ConstructorsExample obj=new ConstructorsExample();
}
	ConstructorsExample(String name_temp,int rolno_temp,String group_temp)
	{
		name=name_temp;
		rolno=rolno_temp;
		group=group_temp;
	}
	ConstructorsExample()
	{
		System.out.println("Dfault constructor executed");
	}
	void display()
	{
			System.out.println("Student name is " +name);
			System.out.println("Student Id is " +rolno);
			System.out.println("Student group is " +group);
	}

}