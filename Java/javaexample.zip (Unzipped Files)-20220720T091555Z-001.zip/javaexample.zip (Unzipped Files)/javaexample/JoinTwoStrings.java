package javaexample;

public class JoinTwoStrings {
	public static void main(String[] args) {

	    // create first string
	    String str1 = "Ashok ";
	    System.out.println("First String: " + str1);

	    // create second
	    String str2 = "Reddy";
	    System.out.println("Second String: " + str2);

	    // join two strings
	    String joinedString = str1.concat(str2);
	    System.out.println("Joined String: " + joinedString);
	  }

}
