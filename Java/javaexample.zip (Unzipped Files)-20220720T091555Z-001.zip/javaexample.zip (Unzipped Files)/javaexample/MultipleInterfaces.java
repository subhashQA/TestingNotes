package javaexample;
interface interface2
{
	void method1();
}
interface interface3
{
	void method2();
}
public class MultipleInterfaces implements interface2, interface3{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MultipleInterfaces obj=new MultipleInterfaces();
		obj.method1();
		obj.method2();
		obj.method3();
	}
	void method3()
	{
		System.out.println("Method 3 code");
	}
	public void method1()
	{
		System.out.println("Defination of method 2");
	}

	public void method2()
	{
		System.out.println("Defination of method 1");
	}

}
