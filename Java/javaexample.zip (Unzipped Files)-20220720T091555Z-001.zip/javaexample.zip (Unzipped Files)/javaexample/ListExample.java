package javaexample;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> values=new ArrayList<Integer>();
		values.add(1);
		values.add(15);
		values.add(44);
		values.add(22);
		values.add(33);
		values.add(1,4);
		Collections.sort(values);
		for(Object i : values)
		{
			System.out.println(i);

		}
		// as we have seen out put it's adding at the last. What if I have to add element in between? Can I use below code?
		//values.add(1,2)// it's not possible add number in between using Arraylist class so we have to go for using List 

	}

}
