package javaexample;
public class Student {

	String name;
	int rolno;
	String group;
	//static String collegeName;
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Student st1=new Student("Ashok", 1, "Mpc");
		//st1.init("Ashok", 1, "Mpc");// function calling
		st1.display();
		Student st2=new Student("Ankush", 2, "BPC");
		//st2.init("Ankush", 2, "BPC");
		st2.display();
		Student st3=new Student("DhanShree", 3, "BPC");
		//st3.init("DhanShree", 3, "BPC");
		st3.display();
		Student st4=new Student();
}
	Student()
	{
		System.out.println("Default constructor execute");
	}
	// Function Defination 
	Student(String name_temp,int rolno_temp,String group_temp)
	{
		name=name_temp;
		rolno=rolno_temp;
		group=group_temp;
	}
	void display()
	{
		System.out.println("Student name is " +name);
		System.out.println("Student Id is " +rolno);
		System.out.println("Student group is " +group);
	}

}
