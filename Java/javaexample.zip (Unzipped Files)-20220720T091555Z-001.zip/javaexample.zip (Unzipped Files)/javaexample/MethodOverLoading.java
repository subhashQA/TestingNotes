package javaexample;

public class MethodOverLoading {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		MethodOverLoading obj=new MethodOverLoading();
		int sum=obj.add(10, 20);
		System.out.println("Sum of two integer numbers are " +sum);
		float total=obj.add(10, 12.40f);
		System.out.println("Sum of one integer and one float numbers are " +total);
		double doubleTotal=obj.add(10.30, 20.40,30.30);
		System.out.println("Sum of three double numbers are " +doubleTotal);

	}
	//function definition
		public int add(int x, int y)
		{
			int sum=x+y;
			return(sum);
		}
		public float add(int x, float y)
		{
			float sum=x+y;
			return(sum);
		}
		public double add(double x, double y,double z)
		{
			double sum=x+y+z;
			return(sum);
		}

}
