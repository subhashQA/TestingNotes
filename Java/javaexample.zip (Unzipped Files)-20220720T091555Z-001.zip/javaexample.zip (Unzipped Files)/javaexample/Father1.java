package javaexample;

public class Father1 {

		public void login()
		{
			System.out.println("login code");
	    }

}

class Chiled extends Father1
{
	public static void main(String[] args) {
		Chiled obj=new Chiled();
		obj.login();
		obj.addBeneficiary();
		
}
	void addBeneficiary()
	{
		System.out.println("Add Beneficiary code");
	}
}
