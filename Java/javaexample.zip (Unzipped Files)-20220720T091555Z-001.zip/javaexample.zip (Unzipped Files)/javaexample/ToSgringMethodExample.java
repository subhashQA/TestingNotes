package javaexample;

public class ToSgringMethodExample {

	int rollno;  
	String name;  
	String city;  
	  
	 ToSgringMethodExample(int rollno, String name, String city){  
	 this.rollno=rollno;  
	 this.name=name;  
	 this.city=city;  
	 }  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ToSgringMethodExample s1=new ToSgringMethodExample(1,"Ashok","Hyderabad");  
		ToSgringMethodExample s2=new ToSgringMethodExample(2,"Anil","Missisaga");  
		System.out.println(s1);//compiler writes here s1.toString()  
		System.out.println(s2);//compiler writes here s2.toString()  
		 }  
	}
	//In this example, printing s1 and s2 prints the hashcode values of the objects
	//but I want to print the values of these objects.
	//Since Java compiler internally calls toString() method