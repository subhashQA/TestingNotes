package javaexample;
public class Animal {
	public void animals()
	{
		System.out.println("Animals can walk");
	}

public static class Dog extends Animal{
	public void animals()
	{
		super.animals();
		System.out.println("Dog can walk and run");
	}
	public static void main(String[] args)	{
	
		//Animal objanimal=new Animal();
		//objanimal.animals();
		Dog obj=new Dog();
		obj.animals();
		
	}
}
}
