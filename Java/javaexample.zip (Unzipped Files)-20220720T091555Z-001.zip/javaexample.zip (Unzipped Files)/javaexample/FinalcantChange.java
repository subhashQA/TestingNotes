package javaexample;

class FinalcantChange
{
	final int x=90;
	void method1()
	{
		System.out.println("Value of x is "+x);
	}
}
class FinalcantChange1 extends FinalcantChange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalcantChange1 obj=new FinalcantChange1();
		obj.method1();
		obj.x=99;
		System.out.println("Value of x" +obj.x);
	}

}
