package pack1;

public class IfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks=30;
		if(marks>=35)
		
			System.out.println("Student is pass");
		
		else
		
			System.out.println("Student is fail");
		

	}

}
