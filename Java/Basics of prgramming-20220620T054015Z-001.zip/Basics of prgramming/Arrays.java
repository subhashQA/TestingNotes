package pack1;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x=new int[5];//here system will allocate 20 bytes of memory
		x[0]=1;
		x[1]=2;
		x[2]=3;
		x[3]=4;
		x[4]=5;
		for(int i=0;i<5;i++)
			System.out.println(x[i]);
		int y[]={1,2,3,4,5};
		

	}

}
