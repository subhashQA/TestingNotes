package pack1;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="Ashok";
		System.out.println("Name is " +name);
		System.out.println(name.length());

	}

}
