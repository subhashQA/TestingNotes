package pack1;

public class For {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++)
			System.out.println("Value of i is " +i);

	}

}
