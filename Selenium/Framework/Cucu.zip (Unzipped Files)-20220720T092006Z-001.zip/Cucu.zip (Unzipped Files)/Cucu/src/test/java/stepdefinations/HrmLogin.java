package stepdefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class HrmLogin {
	
	public static WebDriver driver;
	@Given("browser is open and application is in login page")
	public void user_is_on_home_page() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/");
	}
	@When("user enters user name and password")
	public void user_navigate_to_log_in_page() {
		driver.findElement(By.xpath("//input[@id='txtUsername']")).sendKeys("Admin");
		driver.findElement(By.xpath("//input[@id='txtPassword']")).sendKeys("admin123");
		driver.findElement(By.xpath(" //input[@id='btnLogin']")).click();
	}
	@When("home page is displayed")
	public void user_enters_user_name_and_password() {
	 }
}
