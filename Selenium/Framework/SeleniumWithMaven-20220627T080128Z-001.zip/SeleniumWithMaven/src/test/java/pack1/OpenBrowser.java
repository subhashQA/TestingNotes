package pack1;

public class OpenBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Ashok\\chromedriver.exe");
    	WebDriver driver=new ChromeDriver();


	}

}
