package com.hrm.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ForGotPassword {

	WebDriver driver;
    @FindBy(name="securityAuthentication[userName]")
    public WebElement orangehrmusername;
	@FindBy(name="button")
    public WebElement resetpassword;

}

